module.exports = {
    'secret': 'C-UFRaksvPKhx1txJYFcut3QGxsafPmwCY6SCly3G6c'
}